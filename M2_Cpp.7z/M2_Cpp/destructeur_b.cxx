// created by BOP 5/10/2018
// Université Valrose
// here we go

#include <iostream>
#include <new>
using namespace std;
class intstack{

	int size;
	int n;
	int *tab;
	public:
	intstack(int t): // constructeur
	n(0),size(t){
	if(size<=0)
		cout<<" exception taille negative"<< endl;
	else
		tab=new int [size];
	}
// creation du destructeur


intstack (const intstack & y): // perfect copie constructor on met const pour ne pas changer les valeurs de y
	size(y.size),
	n(y.n),
	tab(new int[size]){
	for(int i=0; i<n;++i){
		tab[i]= y.tab[i];}
	}


// declaration de push pour empiler
void push(int e){
	if(n<size){
		tab[n] = e ;
		n= n+1;
		}
}

// declaration de pop pour dépiler
int pop(){
	if(n==0){
		cout<< "la pile na plus de place"<< endl;} // on a fini de dépiler on peut plus décrementer
	else{
	n=n-1;
	return tab[n];
	}
}

// declaration de fonction print
void print(){
	std::cout << "[ ";
	for(int j=0; j<n; j++){
	cout<<tab[j]<< " ";}
	std::cout << "[ " << std::endl;
	}

// une fonction supprimer pour liberer la memoire
~intstack(){
	delete[] tab;
	}
};


int main(){

intstack s(10);
s.push(7);
intstack t(s);
cout<<"empile la pile t"<< endl;
t.push(9);
t.print();
cout<<"on depile la pile t"<< endl;
t.pop();
t.print();
cout<<"empile la pile s"<< endl;	
s.push(8);
s.print();
cout<<"on depile la pile s"<< endl;
s.pop();
s.print();

}



