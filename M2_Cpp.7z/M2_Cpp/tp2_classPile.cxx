#ifndef intStackDef
#define intStackDef

class intStack{
	//friend intStack add(intStack,intStack); //donne access à cette fct à la variable privé
	
	int size;		//why not *size
	int n;
	int *tab;

	public:	//constructeur 
		intStack(int t): //constructeur
		n(0),size(t){

			if(size<=0)
				std::cout<<" exception taille negative"<< std::endl;
			else
				tab=new int[size];
		}

		void push(int e){
			if(n<size){
				tab[n] = e ;
				n= n+1;
			}
		}
		int pop(){		// declaration de pop pour dépiler
			if(n==0){
				std::cout<< "La pile na plus de place"<< std::endl;} // on a fini de dépiler on peut plus décrementer
			else{
				n=n-1;
			return tab[n];
		}
	}

		void affichage(){	//// declaration de fonction print
			std::cout << "[[STACK[[ ";
			for(int j=0; j<n; j++){
			std::cout << tab[j] << " ";}
			std::cout << " ]]]] " << std::endl;
		}
		intStack (const intStack & y): // perfect copie constructor on met const pour ne pas changer les valeurs de y
			size(y.size),
			n(y.n),
			tab(new int[size]){
			for(int i=0; i<n;++i){
				tab[i]= y.tab[i];}
	}

};

#endif