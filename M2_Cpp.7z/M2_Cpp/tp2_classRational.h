#ifndef rationalDef
#define rationalDef

class rational{
	friend rational add(rational,rational); //donne access à cette fct à la variable privé
	int value;
	int number;

public:	//constructeur 
	rational(int v=17, int n=2):	//liste initialisation
		value(v),
		number(n){}	//on fait rien au initialisation

	void affichage(){
		int num = value;
		int denum = number;
		std::cout << num << "/"<< denum;
	}

	int evaluation(){
		int num = value;
		int denum = number;
		return num/denum;
	}
};

#endif