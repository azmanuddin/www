#include <iostream>
#include "tp3_classIntliste.h"

int main(){
//header
	std::cout <<"#######################\n\n";
	char bon[]="### M2 ESTel = C++_#####.\n";
	int i=0;
	while(bon[i]!='\n'){
		std::cout << bon[i];
		i++;
	}
	std::cout <<"\n TP3 : Class Intliste\n\n";
	std::cout <<"\nCrée par Azman on 12/10/18\n";
	std::cout <<"Modifié par Azman on 12/10/18\n\n";
	std::cout <<"######################\n\n";
//header

//intListe
	intListe l;
	//intListe::intListe();

	l.add_front(17);
	l.add_front(12);
	l.add_back(21);
	

	

	return 0;
}
