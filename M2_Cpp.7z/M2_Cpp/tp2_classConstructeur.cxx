#include <iostream>
#include "tp2_classConstructor.cxx"
#include "tp2_classRational_fct.cxx"

int main(){
//header
	std::cout <<"#######################\n\n";
	char bon[]="### M2 ESTel = C++_#####.\n";
	int i=0;
	while(bon[i]!='\n'){
		std::cout << bon[i];
		i++;
	}
	std::cout <<"\n TP2 : Class Pile\n\n";
	std::cout <<"\nCrée par Azman on 28/09/18\n";
	std::cout <<"Modifié par Azman on 05/10/18\n\n";
	std::cout <<"######################\n\n";
//header

/*************   Pile         **************/
	intStack s(3);
	s.push(11);
	s.push(12);
	
	std::cout <<"######## Debut de Programme Pile   #######\n\n";
	std::cout <<"Ajouter 11 et 12 dans le pile \n\n";
	s.affichage();
	
	std::cout <<"#######################\n\n";
	std::cout <<"Ajouter 13 dans le pile \n\n";
	s.push(13);
	s.affichage();
	
	std::cout <<"#######################\n\n";
	std::cout <<"Enlever element dans le pile \n\n";
	std::cout << s.pop() << std::endl;
	std::cout <<"Enlever element dans le pile \n\n";
	std::cout << s.pop() << std::endl;
	std::cout <<"Enlever element dans le pile \n\n";
	std::cout << s.pop() << std::endl;
	std::cout <<"#######################\n\n";

	std::cout <<"######## Fin de Programme Pile   #######\n\n";

	std::cout <<"######## Debut de Programme Pile (CONSTRUCTEUR)  #######\n\n";

	std::cout <<"##### Contenu de Pile ####\n\n";
	s.affichage();
	
	s.push(7);
	intStack t(s);
	t.push(9);
	s.affichage();
	s.push(8);
	s.affichage();
	std::cout <<"##### Fin de Programme Pile (CONSTRUCTEUR)####\n\n";

	std::cout <<"\n\n##### Debut de Programme Pile (deCONSTRUCTEUR)####\n\n";

	//s(10);
	s.push(7);
	//t(s);		//no match for call to '(intStack) (intStack&)
	cout<<"empile la pile t"<< endl;
	t.push(9);
	t.affichage();
	cout<<"on depile la pile t"<< endl;
	t.pop();
	t.affichage();
	cout<<"empile la pile s"<< endl;	
	s.push(8);
	s.affichage();
	cout<<"on depile la pile s"<< endl;
	s.pop();
	s.affichage();
	std::cout <<"\n\n##### Fin de Programme Pile (deCONSTRUCTEUR)####\n\n";

	return 0;
}
