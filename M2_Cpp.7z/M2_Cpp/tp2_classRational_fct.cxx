#include "tp2_classRational.h"
#ifndef myFct
#define myFct

rational add(rational r1, rational r2){
	float num1,num2,denum1,denum2;
	num1=r1.value;	// int rational.value private
	num2=r2.value;
	denum1=r1.number;
	denum2=r2.number;

	return rational( (num1*denum2+num2*denum1),(denum1*denum2));
	
}
#endif