#include <iostream>

int main(){

	std::cout <<"######################\n\n";
	char bon[]="###Welcom M2 C++_#####.\n";
	int i=0;
	while(bon[i]!='\n'){
		std::cout << bon[i];
		i++;
	}
	std::cout <<"######################\n\n";

	
	return 0;
}
