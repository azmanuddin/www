#ifndef intlisteDef
#define intlisteDef

class intListe{
	

public:	//constructeur 
	
	void affichage(){
		std::cout << "Liste ";
	}


};

#endif