#include <iostream>
#include "tp2_classPile.cxx"
#include "tp2_classRational_fct.cxx"

int main(){
//header
	std::cout <<"#######################\n\n";
	char bon[]="### M2 ESTel = C++_#####.\n";
	int i=0;
	while(bon[i]!='\n'){
		std::cout << bon[i];
		i++;
	}
	std::cout <<"\n TP2 : Class Pile\n\n";
	std::cout <<"\nCrée par Azman on 28/09/18\n";
	std::cout <<"Modifié par Azman on 05/10/18\n\n";
	std::cout <<"######################\n\n";
//header

//pile
	intStack s(3);
	s.push(11);
	s.push(12);
	
	std::cout <<"Ajouter 11 et 12 dans le pile \n\n";
	s.affichage();
	
	std::cout <<"#######################\n\n";
	std::cout <<"Ajouter 13 dans le pile \n\n";
	s.push(13);
	s.affichage();
	
	std::cout <<"#######################\n\n";
	std::cout <<"Enlever element dans le pile \n\n";
	std::cout << s.pop() << std::endl;
	std::cout <<"Enlever element dans le pile \n\n";
	std::cout << s.pop() << std::endl;
	std::cout <<"Enlever element dans le pile \n\n";
	std::cout << s.pop() << std::endl;
	std::cout <<"#######################\n\n";

	std::cout <<"##### Contenu de Pile ####\n\n";
	s.affichage();
	std::cout <<"##### Fin de Programme Pile ####\n\n";

	

	return 0;
}
