// created by BOP 28/09/2018
// Université Valrose
// here we go

#include <iostream>
#include <new>
using namespace std;

class intstack{

	int size;
	int n;
	int *tab;
	
	public:
	intstack(int t): // constructeur
	n(0),size(t){
	if(size<=0)
		cout<<" exception taille negative"<< endl;
	else
		tab=new int [size];
	}

// declaration de push pour empiler
void push(int e){
	if(n<size){
		tab[n] = e ;
		n= n+1;
		}
}

// declaration de pop pour dépiler
int pop(){
	if(n==0){
		cout<< "la pile na plus de place"<< endl;} // on a fini de dépiler on peut plus décrementer
	else{
	n=n-1;
	return tab[n];
	}
}

// declaration de fonction print
void print(){
	std::cout << "[ ";
	for(int j=0; j<n; j++){
	cout<<tab[j]<< " ";}
	std::cout << "[ " << std::endl;
}
// une fonction supprimer pour liberer la memoire
~intstack(){
	delete[] tab;
	}
};


int main(){
	intstack s(3);
	s.push(11);
	s.push(12);
	s.print();
	s.push(13);
	cout<<s.pop() << endl;
	cout<<s.pop() << endl;
	cout<<s.pop() << endl;
	
	s.print();
} 

