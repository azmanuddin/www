#include <iostream>
#include "tp2_classRational.h"
#include "tp2_classRational_fct.cxx"

int main(){
//header
	std::cout <<"#######################\n\n";
	char bon[]="### M2 ESTel = C++_#####.\n";
	int i=0;
	while(bon[i]!='\n'){
		std::cout << bon[i];
		i++;
	}
	std::cout <<"\n TP2 : Class Rational\n\n";
	std::cout <<"\n by Azman on 28/09/18\n\n";
	std::cout <<"######################\n\n";
//header

//Rational code
	rational r1(1,2);
	rational r2(1,3);
	rational r=add(r1,r2);

	//affichage
	std::cout << "##########################\n\n";

	std::cout << "Rational(r) =";
	r1.affichage();
	std::cout << "+";
	r2.affichage();
	std::cout << "=" ;
	r.affichage();

	std::cout << "\n\n ##########################\n\n";
	int v=r.evaluation();

	std::cout << "\n\n Rational(eval) =" << v <<"\n\n";
	//rational r3;
	
	std::cout << "\n\n ##########################\n\n";
	rational r4(2);
	std::cout << "Rational(r4) = " ;
	r4.affichage();

	std::cout << "\n\n ##########################\n\n";

	return 0;
}
